# Halls’n’All (Next.js App Router) — ZIP-ready for Vercel

This project converts the single-file landing into a deployable **Next.js App Router** application with:
- Directory browsing (VenueProfile)
- Matching engine (`matchEvent()` via `/api/match`)
- Booking Request flow with contact verification (OTP in dev)
- Vendor onboarding + billing hooks (Stripe)
- Auth (NextAuth Credentials)
- Basic Admin dashboard (role-based)

## Quick start (local)
1) Copy `.env.example` to `.env` and set `DATABASE_URL` (Postgres).
2) Install deps:
```bash
npm install
```
3) Migrate + seed:
```bash
npx prisma migrate dev --name init
npx prisma db seed
```
4) Run:
```bash
npm run dev
```

## Deploy to Vercel
1) Push this folder to GitHub.
2) Import to Vercel.
3) Add environment variables:
- DATABASE_URL
- NEXTAUTH_URL
- NEXTAUTH_SECRET
- (Optional) Stripe vars:
  - STRIPE_SECRET_KEY
  - STRIPE_WEBHOOK_SECRET
  - STRIPE_VENDOR_SUBSCRIPTION_PRICE_ID

4) Add a Vercel Postgres database and set `DATABASE_URL`.
5) Deploy.

## Stripe notes
- Pay-per-lead uses Stripe Checkout **setup** to collect a payment method.
- Subscription uses Stripe Checkout **subscription** mode.
- Webhook endpoint: `/api/stripe/webhook`

## Webflow/Framer
See `/webflow-framer/index.html` for a static landing you can paste into those builders.
