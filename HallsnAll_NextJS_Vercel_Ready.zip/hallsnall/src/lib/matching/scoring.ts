export type EventIntent = {
  eventType: string;
  guestCount: number;
  budgetMax?: number;
  city?: string;
  state: string;
  cultureTags?: string[];
};

export type InternalScores = {
  capacityMatch: number;
  budgetCompatibility: number;
  eventExpertise: number;
  culturalAlignment: number;
  reliability: number;
};

export type FitResult = {
  eventFitScore: number;
  reasons: string[];
  internal: InternalScores;
};

function clamp(n: number, min = 0, max = 100) {
  return Math.max(min, Math.min(max, n));
}

function scoreCapacityMatch(intent: EventIntent, venue: { minGuests: number | null; maxGuests: number | null }) {
  const guest = intent.guestCount;
  const min = venue.minGuests;
  const max = venue.maxGuests;

  if (min === null && max === null) return 60;
  if (max !== null && guest > max) return 0;
  if (min !== null && guest < min) return 35;

  if (min !== null && max !== null) {
    const mid = (min + max) / 2;
    const half = Math.max((max - min) / 2, 1);
    const dist = Math.abs(guest - mid) / half;
    return clamp(100 - dist * 35);
  }

  return 70;
}

function scoreBudgetCompatibility(intent: EventIntent, venue: { priceMin: number | null; priceMax: number | null }) {
  const b = intent.budgetMax;
  if (!b) return 60;
  const min = venue.priceMin;
  const max = venue.priceMax;

  if (min === null && max === null) return 60;
  if (max !== null && b >= max) return 100;
  if (min !== null && b < min) return clamp(70 - ((min - b) / Math.max(min, 1)) * 80);
  return 80;
}

function scoreEventExpertise(intent: EventIntent, venue: { eventTags: string[] }) {
  const t = intent.eventType.toLowerCase();
  return venue.eventTags?.some(x => x.toLowerCase() === t) ? 85 : 60;
}

function scoreCulturalAlignment(intent: EventIntent, venue: { cultureTags: string[] }) {
  const required = intent.cultureTags ?? [];
  if (required.length === 0) return 60;
  const venueTags = (venue.cultureTags ?? []).map(x => x.toLowerCase());
  const matched = required.filter(r => venueTags.includes(r.toLowerCase())).length;
  return clamp((matched / required.length) * 100);
}

function scoreReliability(venue: { responseRate24h: number; isVerified: boolean }) {
  return clamp((venue.responseRate24h ?? 60) + (venue.isVerified ? 10 : 0));
}

export function computeEventFitScore(intent: EventIntent, venue: {
  minGuests: number | null;
  maxGuests: number | null;
  priceMin: number | null;
  priceMax: number | null;
  eventTags: string[];
  cultureTags: string[];
  responseRate24h: number;
  isVerified: boolean;
}): FitResult {
  const capacityMatch = scoreCapacityMatch(intent, venue);
  const budgetCompatibility = scoreBudgetCompatibility(intent, venue);
  const eventExpertise = scoreEventExpertise(intent, venue);
  const culturalAlignment = scoreCulturalAlignment(intent, venue);
  const reliability = scoreReliability(venue);

  const raw =
    0.30 * capacityMatch +
    0.25 * budgetCompatibility +
    0.20 * eventExpertise +
    0.15 * culturalAlignment +
    0.10 * reliability;

  const eventFitScore = Math.round(clamp(raw));
  const reasons: string[] = [];
  if (capacityMatch >= 80) reasons.push("Strong capacity fit for your guest count.");
  if (budgetCompatibility >= 80) reasons.push("Fits your budget range well.");
  if (eventExpertise >= 80) reasons.push("Experienced with your event type.");
  if ((intent.cultureTags?.length ?? 0) > 0 && culturalAlignment >= 80) reasons.push("Matches your cultural requirements.");
  if (reliability >= 75) reasons.push("High response reliability and verified readiness.");
  if (reasons.length === 0) reasons.push("A solid overall match based on your event details.");

  return { eventFitScore, reasons: reasons.slice(0,3), internal: { capacityMatch, budgetCompatibility, eventExpertise, culturalAlignment, reliability } };
}
