import { db } from "@/lib/db";
import { stripe } from "@/lib/stripe";

export async function qualifyAndCharge(matchRequestId: string) {
  const req = await db.matchRequest.findUnique({
    where: { id: matchRequestId },
    include: { contact: true, venueProfile: true },
  });
  if (!req) return;
  if (!req.contact?.isVerified) return;

  const vendor = await db.vendorAccount.findUnique({ where: { venueProfileId: req.venueProfileId } });

  // If no vendor billing configured, still mark qualified but do not charge.
  if (!vendor || !vendor.isActive) {
    await db.matchRequest.update({ where: { id: req.id }, data: { status: "VERIFIED", isQualified: false } });
    return;
  }

  const minX = vendor.minFitScore ?? 80;
  const qualifies = req.eventFitScore >= minX;

  if (!qualifies) {
    await db.matchRequest.update({ where: { id: req.id }, data: { status: "VERIFIED", isQualified: false } });
    return;
  }

  await db.matchRequest.update({ where: { id: req.id }, data: { status: "QUALIFIED", isQualified: true } });

  // Pay-per-lead immediate charge (PaymentIntent off-session) if configured
  if (!vendor.stripeCustomerId || !vendor.stripePaymentMethodId || !process.env.STRIPE_SECRET_KEY) return;

  const amount = vendor.pricePerLead ?? 3500;

  const charge = await db.leadCharge.create({
    data: { amount, status: "PENDING" },
  });

  await db.matchRequest.update({ where: { id: req.id }, data: { leadChargeId: charge.id } });

  try {
    const pi = await stripe.paymentIntents.create({
      amount,
      currency: "usd",
      customer: vendor.stripeCustomerId,
      payment_method: vendor.stripePaymentMethodId,
      off_session: true,
      confirm: true,
      description: `Qualified match (EventFitScore=${req.eventFitScore})`,
      metadata: { matchRequestId: req.id, venueProfileId: req.venueProfileId },
    });

    await db.leadCharge.update({ where: { id: charge.id }, data: { status: "SUCCEEDED", stripePaymentIntentId: pi.id } });
    await db.matchRequest.update({ where: { id: req.id }, data: { status: "FORWARDED", forwardedAt: new Date() } });
  } catch {
    await db.leadCharge.update({ where: { id: charge.id }, data: { status: "FAILED" } });
  }
}
