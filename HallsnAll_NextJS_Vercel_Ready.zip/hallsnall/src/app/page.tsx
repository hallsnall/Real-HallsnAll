import Link from "next/link";

export default function HomePage() {
  return (
    <main>
      <section style={{background:"#0b0b0b", color:"#fff", padding:"64px 0"}}>
        <div className="container">
          <div className="badge" style={{borderColor:"rgba(255,255,255,.18)", background:"rgba(255,255,255,.06)", color:"#fff"}}>
            Unified Directory + Booking Intelligence
          </div>
          <h1 style={{fontSize:46, lineHeight:1.05, margin:"14px 0 10px"}}>Discover Services. Get Matched. Book with Confidence.</h1>
          <p style={{maxWidth:820, color:"rgba(255,255,255,.85)", fontSize:16}}>
            Halls’n’All is a unified directory and booking intelligence platform for event venues and services—built to serve everyday users, event planners, and vendors with clarity, trust, and real results.
          </p>
          <div style={{display:"flex", gap:10, marginTop:18, flexWrap:"wrap"}}>
            <Link className="btn btnGold" href="/explore">Explore Services</Link>
            <Link className="btn btnPrimary" href="/get-matched">Get Matched</Link>
          </div>
          <div style={{marginTop:14, color:"rgba(255,255,255,.75)"}}>
            <small>Browse freely or use intelligent matching • Transparent Event Fit Score™ • Verified booking requests</small>
          </div>
        </div>
      </section>

      <section style={{padding:"44px 0"}}>
        <div className="container">
          <h2 style={{margin:"0 0 10px"}}>Two ways to find what you need</h2>
          <div className="grid grid2">
            <div className="card">
              <div className="badge">Directory Mode</div>
              <h3 style={{margin:"10px 0 8px"}}>Explore Services</h3>
              <p><small>Browse venues and services by category, city, price, and reviews—perfect for casual discovery.</small></p>
              <Link className="btn" href="/explore">Browse All Services</Link>
            </div>
            <div className="card">
              <div className="badge">Intelligence Mode</div>
              <h3 style={{margin:"10px 0 8px"}}>Get Matched</h3>
              <p><small>Tell us your event needs. We rank the best options using Event Fit Score™.</small></p>
              <Link className="btn btnPrimary" href="/get-matched">Get Smart Matches</Link>
            </div>
          </div>

          <h2 style={{marginTop:34}}>Everything for your event — in one place</h2>
          <div className="grid grid3" style={{marginTop:12}}>
            {[
              "Event Venues & Halls","Catering & Food","DJs & Entertainment","Photography & Video","Decor & Styling","Rentals",
              "Makeup & Fashion","Transport & Valet","Security & Staffing","Cleanup & Logistics"
            ].map((x)=>(
              <div key={x} className="card"><strong>{x}</strong><div><small>Browse or Get Matched.</small></div></div>
            ))}
          </div>

          <div className="card" style={{marginTop:24}}>
            <h3 style={{marginTop:0}}>For Vendors</h3>
            <p><small>Stop getting random inquiries. Start receiving qualified booking requests with verified contacts and measurable ROI.</small></p>
            <div style={{display:"flex", gap:10, flexWrap:"wrap"}}>
              <Link className="btn btnPrimary" href="/vendors/onboard">Join as a Vendor</Link>
              <Link className="btn" href="/pricing">View Pricing</Link>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
