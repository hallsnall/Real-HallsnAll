import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export default async function AdminPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return (
      <main className="container" style={{padding:"28px 0"}}>
        <h1>Admin</h1>
        <p><small>Please sign in.</small></p>
        <Link className="btn btnPrimary" href="/auth/signin">Sign in</Link>
      </main>
    );
  }
  // @ts-expect-error
  const userId = session.user.id as string;
  const user = await db.user.findUnique({ where: { id: userId } });

  if (!user || user.role !== "ADMIN") {
    return (
      <main className="container" style={{padding:"28px 0"}}>
        <h1>Admin</h1>
        <p><small>Access denied.</small></p>
        <Link className="btn" href="/">Go home</Link>
      </main>
    );
  }

  const [users, vendors, requests] = await Promise.all([
    db.user.count(),
    db.vendorAccount.count(),
    db.matchRequest.count(),
  ]);

  const recentVendors = await db.vendorAccount.findMany({ take: 10, orderBy: { createdAt: "desc" }, include: { venueProfile: true, user: true } });
  const recentRequests = await db.matchRequest.findMany({ take: 10, orderBy: { createdAt: "desc" }, include: { venueProfile: true, contact: true } });

  return (
    <main className="container" style={{padding:"28px 0"}}>
      <div className="badge">Admin</div>
      <h1 style={{margin:"10px 0 4px"}}>Operations dashboard</h1>
      <p><small>Moderation, billing, and platform health.</small></p>

      <div className="grid grid3" style={{marginTop:14}}>
        <div className="card"><small>Total users</small><div style={{fontSize:26, fontWeight:800}}>{users}</div></div>
        <div className="card"><small>Vendors</small><div style={{fontSize:26, fontWeight:800}}>{vendors}</div></div>
        <div className="card"><small>Booking requests</small><div style={{fontSize:26, fontWeight:800}}>{requests}</div></div>
      </div>

      <div className="grid grid2" style={{marginTop:14}}>
        <div className="card">
          <h3 style={{marginTop:0}}>Latest vendors</h3>
          <div className="grid" style={{gap:10}}>
            {recentVendors.map(v => (
              <div key={v.id} className="card" style={{padding:12}}>
                <strong>{v.venueProfile.name}</strong>
                <div><small>{v.venueProfile.city}, {v.venueProfile.state} • {v.user.email}</small></div>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <h3 style={{marginTop:0}}>Latest requests</h3>
          <div className="grid" style={{gap:10}}>
            {recentRequests.map(r => (
              <div key={r.id} className="card" style={{padding:12}}>
                <div style={{display:"flex", justifyContent:"space-between", gap:10}}>
                  <strong>{r.venueProfile.name}</strong>
                  <span className="badge">{r.status}</span>
                </div>
                <div><small>{r.eventType} • {r.guestCount} • Fit {r.eventFitScore}</small></div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{marginTop:14}}><small>Tip: Add moderation actions (suspend vendor, refund lead, flag fraud) as Phase 2.</small></div>
    </main>
  );
}
