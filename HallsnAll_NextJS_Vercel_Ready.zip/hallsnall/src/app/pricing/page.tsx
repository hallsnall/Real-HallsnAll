import Link from "next/link";

export default function PricingPage() {
  return (
    <main className="container" style={{padding:"28px 0"}}>
      <h1 style={{margin:"6px 0 4px"}}>Pricing</h1>
      <p><small>Built for bookings—not clicks. Vendors pay for outcomes: qualified, verified booking requests.</small></p>

      <div className="grid grid3" style={{marginTop:14}}>
        <div className="card">
          <div className="badge">Starter</div>
          <h3 style={{margin:"10px 0 6px"}}>Free</h3>
          <ul style={{margin:0, paddingLeft:18}}>
            <li><small>Directory profile</small></li>
            <li><small>Basic visibility</small></li>
            <li><small>Eligibility for matching</small></li>
          </ul>
          <div style={{marginTop:12}}>
            <Link className="btn" href="/vendors/onboard">Join Free</Link>
          </div>
        </div>

        <div className="card">
          <div className="badge">Pro</div>
          <h3 style={{margin:"10px 0 6px"}}>Subscription</h3>
          <small>From <strong>$99/mo</strong> (tiered by city).</small>
          <ul style={{marginTop:10, paddingLeft:18}}>
            <li><small>Priority visibility</small></li>
            <li><small>Analytics</small></li>
            <li><small>Higher match volume</small></li>
          </ul>
          <div style={{marginTop:12}}>
            <Link className="btn btnPrimary" href="/vendors/onboard">Start Pro</Link>
          </div>
        </div>

        <div className="card">
          <div className="badge">IQ Leads™</div>
          <h3 style={{margin:"10px 0 6px"}}>Pay per Qualified Match</h3>
          <small>Charged only when Event Fit Score ≥ your threshold and contact is verified.</small>
          <ul style={{marginTop:10, paddingLeft:18}}>
            <li><small>Fit threshold control</small></li>
            <li><small>Lead caps</small></li>
            <li><small>Verified contacts</small></li>
          </ul>
          <div style={{marginTop:12}}>
            <Link className="btn btnGold" href="/vendors/onboard">Enable IQ Leads™</Link>
          </div>
        </div>
      </div>
    </main>
  );
}
