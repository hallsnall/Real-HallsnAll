import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return (
      <main className="container" style={{padding:"28px 0"}}>
        <h1>Dashboard</h1>
        <p><small>Please sign in to continue.</small></p>
        <Link className="btn btnPrimary" href="/auth/signin">Sign in</Link>
      </main>
    );
  }

  // @ts-expect-error id exists via session augmentation in layout
  const userId = session.user.id as string;

  const recent = await db.matchRequest.findMany({
    where: { userId },
    take: 10,
    orderBy: { createdAt: "desc" },
    include: { venueProfile: true },
  });

  return (
    <main className="container" style={{padding:"28px 0"}}>
      <h1 style={{margin:"6px 0 4px"}}>Your dashboard</h1>
      <p><small>Saved services and booking requests will appear here.</small></p>

      <div className="card" style={{marginTop:14}}>
        <h3 style={{marginTop:0}}>Recent booking requests</h3>
        {recent.length === 0 ? (
          <p><small>No requests yet. Use <Link href="/get-matched"><u>Get Matched</u></Link> to start.</small></p>
        ) : (
          <div className="grid" style={{gap:10}}>
            {recent.map(r => (
              <div key={r.id} className="card" style={{padding:14}}>
                <div style={{display:"flex", justifyContent:"space-between", gap:10, alignItems:"center"}}>
                  <div>
                    <strong>{r.venueProfile.name}</strong>
                    <div><small>{r.eventType} • {r.guestCount} guests</small></div>
                  </div>
                  <div className="badge">{r.status}</div>
                </div>
                <div style={{marginTop:8}}><small>Event Fit Score used: <strong>{r.eventFitScore}</strong></small></div>
              </div>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
