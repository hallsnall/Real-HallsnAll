import MatchClient from "./ui/MatchClient";

export default function GetMatchedPage() {
  return (
    <main className="container" style={{padding:"28px 0"}}>
      <h1 style={{margin:"6px 0 4px"}}>Get Matched</h1>
      <p><small>Answer a few questions. We’ll rank the best options using Event Fit Score™.</small></p>
      <div style={{marginTop:14}}>
        <MatchClient />
      </div>
    </main>
  );
}
