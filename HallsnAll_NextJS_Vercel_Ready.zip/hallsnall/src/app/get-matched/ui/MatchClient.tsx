"use client";

import { useState } from "react";
import Link from "next/link";

type Match = {
  id: string;
  slug: string;
  name: string;
  city: string;
  state: string;
  eventFitScore: number;
  reasons: string[];
};

export default function MatchClient() {
  const [eventType, setEventType] = useState("wedding");
  const [guestCount, setGuestCount] = useState(150);
  const [budgetMax, setBudgetMax] = useState<number | "">(6000);
  const [state, setState] = useState("NY");
  const [city, setCity] = useState("");
  const [loading, setLoading] = useState(false);
  const [matches, setMatches] = useState<Match[] | null>(null);
  const [error, setError] = useState("");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    setMatches(null);
    try {
      const res = await fetch("/api/match", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          eventType,
          guestCount: Number(guestCount),
          budgetMax: budgetMax === "" ? undefined : Number(budgetMax),
          state,
          city: city.trim() ? city.trim() : undefined,
        }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) throw new Error(data?.error ?? "Failed to match.");
      setMatches(data.matches);
    } catch (e: any) {
      setError(e?.message ?? "Could not match.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid grid2">
      <form onSubmit={submit} className="card">
        <div className="badge">Intelligence Mode</div>
        <h3 style={{margin:"10px 0 10px"}}>Event details</h3>

        <div style={{marginBottom:10}}>
          <label>Event type</label>
          <select value={eventType} onChange={(e)=>setEventType(e.target.value)}>
            {["wedding","birthday","corporate","religious","funeral","conference","other"].map(x=>(
              <option key={x} value={x}>{x}</option>
            ))}
          </select>
        </div>

        <div style={{marginBottom:10}}>
          <label>Guest count</label>
          <input type="number" min={1} value={guestCount} onChange={(e)=>setGuestCount(Number(e.target.value))} />
        </div>

        <div style={{marginBottom:10}}>
          <label>Budget max (optional)</label>
          <input type="number" min={0} value={budgetMax} onChange={(e)=>setBudgetMax(e.target.value === "" ? "" : Number(e.target.value))} />
        </div>

        <div className="grid grid2" style={{gap:10}}>
          <div>
            <label>State</label>
            <input value={state} onChange={(e)=>setState(e.target.value.toUpperCase())} />
          </div>
          <div>
            <label>City (optional)</label>
            <input value={city} onChange={(e)=>setCity(e.target.value)} />
          </div>
        </div>

        {error ? <div style={{color:"#b91c1c", marginTop:10}}><small>{error}</small></div> : null}
        <button className="btn btnPrimary" style={{marginTop:12, width:"100%"}} disabled={loading}>
          {loading ? "Matching..." : "Get Matched"}
        </button>
        <div style={{marginTop:10}}>
          <small>Prefer browsing? <Link href="/explore"><u>Explore Services</u></Link>.</small>
        </div>
      </form>

      <div className="card">
        <div className="badge">Match Results</div>
        <h3 style={{margin:"10px 0 10px"}}>Top matches</h3>
        {!matches ? (
          <p><small>Submit your event details to see ranked results with Event Fit Score™.</small></p>
        ) : matches.length === 0 ? (
          <p><small>No matches found. Try a different city or state.</small></p>
        ) : (
          <div className="grid" style={{gap:12}}>
            {matches.map(m => (
              <div key={m.id} className="card" style={{padding:14}}>
                <div style={{display:"flex", justifyContent:"space-between", gap:10, alignItems:"center"}}>
                  <div>
                    <strong>{m.name}</strong>
                    <div><small>{m.city}, {m.state}</small></div>
                  </div>
                  <div className="badge"><strong>{m.eventFitScore}</strong> Fit</div>
                </div>
                <ul style={{margin:"10px 0 0", paddingLeft:18}}>
                  {m.reasons.slice(0,3).map((r, i)=>(
                    <li key={i}><small>{r}</small></li>
                  ))}
                </ul>
                <div style={{display:"flex", gap:10, flexWrap:"wrap", marginTop:10}}>
                  <Link className="btn btnPrimary" href={`/book/request?venue=${encodeURIComponent(m.slug)}`}>Request</Link>
                  <Link className="btn" href={`/venues/${m.slug}`}>View Profile</Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
