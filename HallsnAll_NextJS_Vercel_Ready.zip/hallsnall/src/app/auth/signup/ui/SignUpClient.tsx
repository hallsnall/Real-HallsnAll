"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import Link from "next/link";

export default function SignUpClient() {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({ email, name, password })
      });
      const data = await res.json().catch(()=>null);
      if (!res.ok) throw new Error(data?.error ?? "Registration failed");
      await signIn("credentials", { email, password, redirect: true, callbackUrl: "/dashboard" });
    } catch (e:any) {
      setErr(e?.message ?? "Could not register.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form className="card" onSubmit={submit}>
      <div style={{marginBottom:10}}>
        <label>Name (optional)</label>
        <input value={name} onChange={(e)=>setName(e.target.value)} />
      </div>
      <div style={{marginBottom:10}}>
        <label>Email</label>
        <input value={email} onChange={(e)=>setEmail(e.target.value)} />
      </div>
      <div style={{marginBottom:10}}>
        <label>Password</label>
        <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} />
        <small>Minimum 6 characters.</small>
      </div>
      {err ? <div style={{color:"#b91c1c"}}><small>{err}</small></div> : null}
      <button className="btn btnPrimary" style={{width:"100%", marginTop:12}} disabled={loading}>
        {loading ? "Creating..." : "Create account"}
      </button>
      <div style={{marginTop:10}}><small>Already have an account? <Link href="/auth/signin"><u>Sign in</u></Link>.</small></div>
    </form>
  );
}
