import SignUpClient from "./ui/SignUpClient";

export default function SignUpPage() {
  return (
    <main className="container" style={{padding:"28px 0", maxWidth:520}}>
      <h1 style={{margin:"6px 0 4px"}}>Create account</h1>
      <p><small>Create an account to save services and submit verified booking requests.</small></p>
      <div style={{marginTop:14}}>
        <SignUpClient />
      </div>
    </main>
  );
}
