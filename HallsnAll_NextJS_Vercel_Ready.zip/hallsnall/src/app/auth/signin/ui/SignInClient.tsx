"use client";

import { signIn } from "next-auth/react";
import { useState } from "react";
import Link from "next/link";

export default function SignInClient() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    setLoading(true);
    const res = await signIn("credentials", { email, password, redirect: true, callbackUrl: "/dashboard" });
    // If redirect happens, res can be undefined; keep simple.
    setLoading(false);
    if ((res as any)?.error) setErr("Invalid credentials.");
  }

  return (
    <form className="card" onSubmit={submit}>
      <div style={{marginBottom:10}}>
        <label>Email</label>
        <input value={email} onChange={(e)=>setEmail(e.target.value)} />
      </div>
      <div style={{marginBottom:10}}>
        <label>Password</label>
        <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} />
      </div>
      {err ? <div style={{color:"#b91c1c"}}><small>{err}</small></div> : null}
      <button className="btn btnPrimary" style={{width:"100%", marginTop:12}} disabled={loading}>
        {loading ? "Signing in..." : "Sign in"}
      </button>
      <div style={{marginTop:10}}><small>New here? <Link href="/auth/signup"><u>Create an account</u></Link>.</small></div>
    </form>
  );
}
