import SignInClient from "./ui/SignInClient";

export default function SignInPage() {
  return (
    <main className="container" style={{padding:"28px 0", maxWidth:520}}>
      <h1 style={{margin:"6px 0 4px"}}>Sign in</h1>
      <p><small>Use email and password for this MVP. Admin and vendor roles are set in the database.</small></p>
      <div style={{marginTop:14}}>
        <SignInClient />
      </div>
    </main>
  );
}
