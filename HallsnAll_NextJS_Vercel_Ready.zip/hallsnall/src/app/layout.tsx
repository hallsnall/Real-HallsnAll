import "./../styles/globals.css";
import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export const metadata = {
  title: "Halls’n’All — Discover. Get Matched. Book with Confidence.",
  description: "Unified directory and booking intelligence platform for event venues and services."
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  return (
    <html lang="en">
      <body>
        <header style={{borderBottom:"1px solid #f1f5f9", background:"#fff"}}>
          <div className="container" style={{display:"flex", alignItems:"center", justifyContent:"space-between", padding:"14px 20px"}}>
            <Link href="/" style={{fontWeight:800}}>Halls’n’All</Link>
            <nav style={{display:"flex", gap:"14px", alignItems:"center"}}>
              <Link href="/explore" className="badge">Explore Services</Link>
              <Link href="/get-matched" className="badge">Get Matched</Link>
              <Link href="/pricing" className="badge">Pricing</Link>
              <Link href="/vendors/onboard" className="badge">Vendors</Link>
              {session?.user ? (
                <>
                  <Link href="/dashboard" className="badge">Dashboard</Link>
                  <Link href="/api/auth/signout" className="badge">Sign out</Link>
                </>
              ) : (
                <Link href="/auth/signin" className="badge">Sign in</Link>
              )}
            </nav>
          </div>
        </header>
        {children}
        <footer style={{borderTop:"1px solid #f1f5f9", marginTop:40, padding:"26px 0", background:"#fff"}}>
          <div className="container" style={{display:"flex", justifyContent:"space-between", gap:16, flexWrap:"wrap"}}>
            <div>
              <div style={{fontWeight:800}}>Halls’n’All</div>
              <small>Unified directory + booking intelligence.</small>
            </div>
            <div style={{display:"flex", gap:12}}>
              <Link href="/terms">Terms</Link>
              <Link href="/privacy">Privacy</Link>
            </div>
          </div>
        </footer>
      </body>
    </html>
  );
}
