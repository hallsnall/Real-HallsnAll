export default function PrivacyPage() {
  return (
    <main className="container" style={{padding:"28px 0", maxWidth:900}}>
      <h1 style={{margin:"6px 0 4px"}}>Privacy</h1>
      <p><small>We collect only the information needed to provide discovery, matching, and verified booking communication. Verified contact details are shared with vendors only after a booking request is submitted and verified.</small></p>
      <p><small>We may use aggregated, anonymized analytics to improve matching quality and platform performance.</small></p>
      <p><small>This is an MVP privacy page. Replace with your finalized legal PDFs for production.</small></p>
    </main>
  );
}
