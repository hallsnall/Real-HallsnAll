import BookingRequestForm from "./ui/BookingRequestForm";

export default function BookingRequestPage() {
  return (
    <main className="container" style={{padding:"28px 0", maxWidth:760}}>
      <h1 style={{margin:"6px 0 4px"}}>Request Smart Booking</h1>
      <p><small>Submit your request and verify contact. Vendors are charged only for qualified, verified matches.</small></p>
      <div style={{marginTop:14}}>
        <BookingRequestForm />
      </div>
    </main>
  );
}
