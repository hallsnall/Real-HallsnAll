"use client";

import { useSearchParams, useRouter } from "next/navigation";
import { useState } from "react";

export default function BookingRequestForm() {
  const sp = useSearchParams();
  const router = useRouter();
  const venueSlug = sp.get("venue") ?? "";

  const [eventType, setEventType] = useState("wedding");
  const [guestCount, setGuestCount] = useState(150);
  const [budgetMax, setBudgetMax] = useState<number | "">(6000);
  const [state, setState] = useState("NY");
  const [city, setCity] = useState("");
  const [message, setMessage] = useState("");
  const [channel, setChannel] = useState<"EMAIL" | "PHONE">("EMAIL");
  const [value, setValue] = useState("");

  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    setLoading(true);
    try {
      const res = await fetch("/api/book/request", {
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({
          venueSlug,
          intent: { eventType, guestCount, budgetMax: budgetMax === "" ? undefined : Number(budgetMax), state, city: city || undefined },
          message: message || undefined,
          contact: { channel, value }
        })
      });
      const data = await res.json().catch(()=>null);
      if (!res.ok) throw new Error(data?.error ?? "Submission failed");
      // pass devOtp for convenience if present
      router.push(`/book/verify?request=${encodeURIComponent(data.matchRequestId)}${data.devOtp ? `&otp=${encodeURIComponent(data.devOtp)}` : ""}`);
    } catch (e:any) {
      setErr(e?.message ?? "Could not submit.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form className="card" onSubmit={submit}>
      <div className="grid grid2">
        <div>
          <label>Venue</label>
          <input value={venueSlug} disabled />
          <small>Chosen from VenueProfile page or match results.</small>
        </div>
        <div>
          <label>Event type</label>
          <select value={eventType} onChange={(e)=>setEventType(e.target.value)}>
            {["wedding","birthday","corporate","religious","funeral","conference","other"].map(x=>(
              <option key={x} value={x}>{x}</option>
            ))}
          </select>
        </div>
        <div>
          <label>Guest count</label>
          <input type="number" min={1} value={guestCount} onChange={(e)=>setGuestCount(Number(e.target.value))} />
        </div>
        <div>
          <label>Budget max (optional)</label>
          <input type="number" min={0} value={budgetMax} onChange={(e)=>setBudgetMax(e.target.value === "" ? "" : Number(e.target.value))} />
        </div>
        <div>
          <label>State</label>
          <input value={state} onChange={(e)=>setState(e.target.value.toUpperCase())} />
        </div>
        <div>
          <label>City (optional)</label>
          <input value={city} onChange={(e)=>setCity(e.target.value)} />
        </div>
      </div>

      <div style={{marginTop:10}}>
        <label>Message (optional)</label>
        <textarea rows={4} value={message} onChange={(e)=>setMessage(e.target.value)} />
      </div>

      <hr />

      <div className="grid grid2">
        <div>
          <label>Contact channel</label>
          <select value={channel} onChange={(e)=>setChannel(e.target.value as any)}>
            <option value="EMAIL">Email</option>
            <option value="PHONE">Phone</option>
          </select>
        </div>
        <div>
          <label>{channel === "EMAIL" ? "Email" : "Phone"}</label>
          <input value={value} onChange={(e)=>setValue(e.target.value)} />
          <small>We will verify this before sending to vendors.</small>
        </div>
      </div>

      {err ? <div style={{color:"#b91c1c", marginTop:10}}><small>{err}</small></div> : null}
      <button className="btn btnPrimary" style={{width:"100%", marginTop:12}} disabled={loading}>
        {loading ? "Submitting..." : "Submit & Verify"}
      </button>
    </form>
  );
}
