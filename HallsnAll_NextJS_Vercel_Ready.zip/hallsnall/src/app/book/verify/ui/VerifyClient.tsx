"use client";

import { useSearchParams, useRouter } from "next/navigation";
import { useState } from "react";

export default function VerifyClient() {
  const sp = useSearchParams();
  const router = useRouter();
  const requestId = sp.get("request") ?? "";
  const devOtp = sp.get("otp") ?? "";

  const [otp, setOtp] = useState(devOtp);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    setLoading(true);
    try {
      const res = await fetch("/api/book/verify", {
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({ matchRequestId: requestId, otp })
      });
      const data = await res.json().catch(()=>null);
      if (!res.ok) throw new Error(data?.error ?? "Verification failed");
      router.push(`/book/confirmed?request=${encodeURIComponent(requestId)}`);
    } catch (e:any) {
      setErr(e?.message ?? "Could not verify.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form className="card" onSubmit={submit}>
      <label>Verification code</label>
      <input value={otp} onChange={(e)=>setOtp(e.target.value)} />
      {devOtp ? <div style={{marginTop:6}}><small><strong>Dev code:</strong> {devOtp}</small></div> : null}
      {err ? <div style={{color:"#b91c1c", marginTop:10}}><small>{err}</small></div> : null}
      <button className="btn btnPrimary" style={{width:"100%", marginTop:12}} disabled={loading}>
        {loading ? "Verifying..." : "Verify"}
      </button>
    </form>
  );
}
