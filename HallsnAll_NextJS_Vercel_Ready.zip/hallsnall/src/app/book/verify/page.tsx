import VerifyClient from "./ui/VerifyClient";

export default function VerifyPage() {
  return (
    <main className="container" style={{padding:"28px 0", maxWidth:520}}>
      <h1 style={{margin:"6px 0 4px"}}>Verify your contact</h1>
      <p><small>Enter the verification code. In development mode, we may show the code for testing.</small></p>
      <div style={{marginTop:14}}>
        <VerifyClient />
      </div>
    </main>
  );
}
