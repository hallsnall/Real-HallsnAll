import Link from "next/link";

export default function ConfirmedPage() {
  return (
    <main className="container" style={{padding:"28px 0", maxWidth:680}}>
      <h1 style={{margin:"6px 0 4px"}}>Request received</h1>
      <p><small>Your contact is verified. If your request qualifies (Event Fit Score threshold), it will be forwarded to the vendor.</small></p>
      <div style={{display:"flex", gap:10, marginTop:14, flexWrap:"wrap"}}>
        <Link className="btn btnPrimary" href="/dashboard">Go to dashboard</Link>
        <Link className="btn" href="/get-matched">Get more matches</Link>
      </div>
    </main>
  );
}
