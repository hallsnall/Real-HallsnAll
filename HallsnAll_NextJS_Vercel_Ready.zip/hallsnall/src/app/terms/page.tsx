export default function TermsPage() {
  return (
    <main className="container" style={{padding:"28px 0", maxWidth:900}}>
      <h1 style={{margin:"6px 0 4px"}}>Terms</h1>
      <p><small><strong>Platform Role.</strong> Halls’n’All is a neutral directory and booking intelligence platform. We do not provide event services and are not a party to contracts between users and vendors.</small></p>
      <p><small><strong>Event Fit Score™.</strong> Scores and recommendations are advisory tools and do not guarantee availability, pricing, or outcomes.</small></p>
      <p><small><strong>Qualified Match Billing.</strong> Vendors may be charged only for requests that meet qualification criteria (verified contact + threshold), subject to applicable plan rules.</small></p>
      <p><small><strong>Limitation of Liability.</strong> To the maximum extent permitted by law, our liability is limited to fees paid to us in the prior three (3) months.</small></p>
      <p><small>This is an MVP terms page. Replace with your finalized legal PDFs for production.</small></p>
    </main>
  );
}
