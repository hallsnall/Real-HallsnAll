import Link from "next/link";
import { db } from "@/lib/db";

export default async function VenueProfilePage({ params }: { params: { slug: string } }) {
  const venue = await db.venueProfile.findUnique({ where: { slug: params.slug } });
  if (!venue) return <main className="container" style={{padding:"28px 0"}}>Not found.</main>;
  return (
    <main className="container" style={{padding:"28px 0"}}>
      <div className="badge">VenueProfile</div>
      <h1 style={{margin:"10px 0 4px"}}>{venue.name}</h1>
      <p><small>{venue.city}, {venue.state}</small></p>
      <div className="card" style={{marginTop:14}}>
        <h3 style={{marginTop:0}}>About</h3>
        <p><small>{venue.description ?? "A verified venue profile on Halls’n’All."}</small></p>
        <hr />
        <div className="grid grid2">
          <div>
            <div><small><strong>Guest Capacity</strong></small></div>
            <div><small>{venue.minGuests ?? "—"} to {venue.maxGuests ?? "—"}</small></div>
          </div>
          <div>
            <div><small><strong>Pricing</strong></small></div>
            <div><small>{venue.priceMin ? `$${venue.priceMin}` : "—"} to {venue.priceMax ? `$${venue.priceMax}` : "—"}</small></div>
          </div>
        </div>
        <hr />
        <div style={{display:"flex", gap:10, flexWrap:"wrap"}}>
          <Link className="btn btnPrimary" href={`/book/request?venue=${encodeURIComponent(venue.slug)}`}>Request Smart Booking</Link>
          <Link className="btn" href={`/get-matched?state=${venue.state}&city=${venue.city}`}>Match Similar</Link>
        </div>
      </div>
    </main>
  );
}
