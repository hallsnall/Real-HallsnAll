import Link from "next/link";
import { db } from "@/lib/db";

export default async function ExplorePage() {
  const venues = await db.venueProfile.findMany({ take: 30, orderBy: { updatedAt: "desc" } });
  return (
    <main className="container" style={{padding:"28px 0"}}>
      <h1 style={{margin:"6px 0 4px"}}>Explore Services</h1>
      <p><small>Browse Venue Profiles and services. Prefer recommendations? <Link href="/get-matched"><u>Get Matched</u></Link>.</small></p>
      <div className="grid grid3" style={{marginTop:14}}>
        {venues.map(v => (
          <Link key={v.id} href={`/venues/${v.slug}`} className="card">
            <div className="badge">VenueProfile</div>
            <h3 style={{margin:"10px 0 6px"}}>{v.name}</h3>
            <small>{v.city}, {v.state}</small>
            <div style={{marginTop:10, display:"flex", gap:8, flexWrap:"wrap"}}>
              {v.priceMin ? <span className="badge">${v.priceMin}+ </span> : null}
              {v.maxGuests ? <span className="badge">Up to {v.maxGuests} guests</span> : null}
            </div>
          </Link>
        ))}
      </div>
    </main>
  );
}
