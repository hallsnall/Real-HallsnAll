import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { computeEventFitScore } from "@/lib/matching/scoring";

const IntentSchema = z.object({
  eventType: z.string().min(1),
  guestCount: z.number().int().positive(),
  budgetMax: z.number().int().positive().optional(),
  city: z.string().optional(),
  state: z.string().min(2),
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = IntentSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid event intent payload." }, { status: 400 });
  }

  const intent = parsed.data;

  const venues = await db.venueProfile.findMany({
    where: {
      state: intent.state,
      ...(intent.city ? { city: intent.city } : {}),
    },
    take: 60,
    orderBy: { updatedAt: "desc" },
  });

  const matches = venues
    .map(v => {
      const fit = computeEventFitScore(
        {
          eventType: intent.eventType as any,
          guestCount: intent.guestCount,
          budgetMax: intent.budgetMax,
          city: intent.city,
          state: intent.state,
        },
        {
          minGuests: v.minGuests ?? null,
          maxGuests: v.maxGuests ?? null,
          priceMin: v.priceMin ?? null,
          priceMax: v.priceMax ?? null,
          eventTags: v.eventTags,
          cultureTags: v.cultureTags,
          responseRate24h: v.responseRate24h ?? 60,
          isVerified: v.isVerified,
        }
      );

      return {
        id: v.id,
        slug: v.slug,
        name: v.name,
        city: v.city,
        state: v.state,
        eventFitScore: fit.eventFitScore,
        reasons: fit.reasons,
        _internal: fit.internal,
      };
    })
    .sort((a, b) => (b.eventFitScore - a.eventFitScore) || ((b._internal?.reliability ?? 0) - (a._internal?.reliability ?? 0)))
    .slice(0, 20)
    .map(({ _internal, ...pub }) => pub);

  return NextResponse.json({ intent, matches });
}
