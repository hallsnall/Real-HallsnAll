import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { computeEventFitScore } from "@/lib/matching/scoring";
import { genOtp, sha256 } from "@/lib/crypto";

const Schema = z.object({
  venueSlug: z.string().min(1),
  intent: z.object({
    eventType: z.string().min(1),
    guestCount: z.number().int().positive(),
    budgetMax: z.number().int().positive().optional(),
    state: z.string().min(2),
    city: z.string().optional(),
  }),
  message: z.string().optional(),
  contact: z.object({
    channel: z.enum(["EMAIL","PHONE"]),
    value: z.string().min(3),
  }),
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = Schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid payload." }, { status: 400 });

  const venue = await db.venueProfile.findUnique({ where: { slug: parsed.data.venueSlug } });
  if (!venue) return NextResponse.json({ error: "VenueProfile not found." }, { status: 404 });

  const fit = computeEventFitScore(
    {
      eventType: parsed.data.intent.eventType,
      guestCount: parsed.data.intent.guestCount,
      budgetMax: parsed.data.intent.budgetMax,
      city: parsed.data.intent.city,
      state: parsed.data.intent.state,
    },
    {
      minGuests: venue.minGuests ?? null,
      maxGuests: venue.maxGuests ?? null,
      priceMin: venue.priceMin ?? null,
      priceMax: venue.priceMax ?? null,
      eventTags: venue.eventTags,
      cultureTags: venue.cultureTags,
      responseRate24h: venue.responseRate24h ?? 60,
      isVerified: venue.isVerified,
    }
  );

  const channel = parsed.data.contact.channel;
  const value = parsed.data.contact.value.trim();
  const otp = genOtp();
  const otpHash = sha256(otp);
  const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000);

  const contact = await db.verifiedContact.upsert({
    where: { channel_value: { channel, value } },
    create: { channel, value, otpHash, otpExpiresAt, isVerified: false },
    update: { otpHash, otpExpiresAt, isVerified: false, verifiedAt: null },
  });

  const matchRequest = await db.matchRequest.create({
    data: {
      eventType: parsed.data.intent.eventType,
      guestCount: parsed.data.intent.guestCount,
      budgetMax: parsed.data.intent.budgetMax,
      city: parsed.data.intent.city ?? null,
      state: parsed.data.intent.state,
      cultureTags: [],
      message: parsed.data.message ?? null,
      venueProfileId: venue.id,
      eventFitScore: fit.eventFitScore,
      reasons: fit.reasons,
      contactId: contact.id,
    },
    select: { id: true },
  });

  const isDev = process.env.NODE_ENV !== "production";
  return NextResponse.json({ matchRequestId: matchRequest.id, ...(isDev ? { devOtp: otp } : {}) });
}
