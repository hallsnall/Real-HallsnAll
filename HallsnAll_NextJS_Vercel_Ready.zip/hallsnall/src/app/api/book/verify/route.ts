import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { sha256 } from "@/lib/crypto";
import { qualifyAndCharge } from "@/lib/leads/qualifyAndCharge";

const Schema = z.object({
  matchRequestId: z.string().min(1),
  otp: z.string().min(4),
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = Schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid payload." }, { status: 400 });

  const matchRequest = await db.matchRequest.findUnique({
    where: { id: parsed.data.matchRequestId },
    include: { contact: true },
  });
  if (!matchRequest?.contact) return NextResponse.json({ error: "Request not found." }, { status: 404 });

  if (!matchRequest.contact.otpHash || !matchRequest.contact.otpExpiresAt) {
    return NextResponse.json({ error: "No verification pending." }, { status: 400 });
  }
  if (new Date() > matchRequest.contact.otpExpiresAt) {
    return NextResponse.json({ error: "Code expired. Resubmit request." }, { status: 400 });
  }

  if (sha256(parsed.data.otp) !== matchRequest.contact.otpHash) {
    return NextResponse.json({ error: "Invalid code." }, { status: 400 });
  }

  await db.$transaction([
    db.verifiedContact.update({
      where: { id: matchRequest.contact.id },
      data: { isVerified: true, verifiedAt: new Date(), otpHash: null, otpExpiresAt: null },
    }),
    db.matchRequest.update({
      where: { id: matchRequest.id },
      data: { status: "VERIFIED" },
    }),
  ]);

  await qualifyAndCharge(matchRequest.id);

  return NextResponse.json({ ok: true });
}
