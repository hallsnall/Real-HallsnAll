import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { stripe } from "@/lib/stripe";
import { db } from "@/lib/db";

export async function POST(req: Request) {
  const sig = headers().get("stripe-signature");
  const whsec = process.env.STRIPE_WEBHOOK_SECRET;
  if (!sig || !whsec) return NextResponse.json({ error: "Missing webhook config." }, { status: 400 });

  const raw = await req.text();
  let event;
  try {
    event = stripe.webhooks.constructEvent(raw, sig, whsec);
  } catch (err: any) {
    return NextResponse.json({ error: `Webhook error: ${err.message}` }, { status: 400 });
  }

  // Handle checkout completion for setup/subscription
  if (event.type === "checkout.session.completed") {
    const session = event.data.object as any;
    const vendorAccountId = session.metadata?.vendorAccountId;
    if (vendorAccountId) {
      // If setup mode, grab customer default payment method
      if (session.mode === "setup") {
        // Fetch customer and store default payment method if present
        const customer = await stripe.customers.retrieve(session.customer as string);
        const pm = (customer as any).invoice_settings?.default_payment_method as string | undefined;

        if (pm) {
          await db.vendorAccount.update({
            where: { id: vendorAccountId },
            data: { stripeCustomerId: session.customer as string, stripePaymentMethodId: pm },
          });
        }
      }

      // If subscription mode, store subscription id
      if (session.mode === "subscription") {
        await db.vendorAccount.update({
          where: { id: vendorAccountId },
          data: { stripeCustomerId: session.customer as string, stripeSubscriptionId: session.subscription as string },
        });
      }
    }
  }

  return NextResponse.json({ received: true });
}
