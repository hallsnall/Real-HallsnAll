import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const db = new PrismaClient();

async function main() {
  // Admin user
  const adminEmail = "admin@hallsnall.com";
  const adminPass = "ChangeMe123!";
  const adminHash = await bcrypt.hash(adminPass, 10);

  await db.user.upsert({
    where: { email: adminEmail },
    update: {},
    create: { email: adminEmail, passwordHash: adminHash, role: "ADMIN", name: "Admin" },
  });

  const venues = [
    { slug:"golden-terrace-hall", name:"Golden Terrace Hall", city:"New York", state:"NY", priceMin:5000, priceMax:18000, minGuests:80, maxGuests:350, eventTags:["wedding","corporate"], isVerified:true, responseRate24h:80 },
    { slug:"skyline-ballroom", name:"Skyline Ballroom", city:"New York", state:"NY", priceMin:3000, priceMax:12000, minGuests:50, maxGuests:220, eventTags:["birthday","wedding"], isVerified:false, responseRate24h:65 },
    { slug:"harbor-view-events", name:"Harbor View Events", city:"Brooklyn", state:"NY", priceMin:4000, priceMax:15000, minGuests:60, maxGuests:300, eventTags:["wedding","conference"], isVerified:true, responseRate24h:78 },
  ];

  for (const v of venues) {
    await db.venueProfile.upsert({
      where: { slug: v.slug },
      update: { ...v },
      create: { ...v, cultureTags: [], description: "A premium venue profile on Halls’n’All." },
    });
  }

  console.log("Seed complete.");
  console.log("Admin login:");
  console.log("  email:", adminEmail);
  console.log("  password:", adminPass);
}

main().finally(async () => {
  await db.$disconnect();
});
